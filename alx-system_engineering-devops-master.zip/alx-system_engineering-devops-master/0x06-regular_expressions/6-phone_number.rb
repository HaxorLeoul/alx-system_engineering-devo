#!/usr/bin/env ruby
puts ARGV[0].scan(/\S[0-9]{9}/).join