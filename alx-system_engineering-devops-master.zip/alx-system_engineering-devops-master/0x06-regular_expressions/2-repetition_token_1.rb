#!/usr/bin/env ruby
puts ARGV[0].scan(/hb?tn/).join