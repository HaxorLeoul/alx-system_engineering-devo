#!/usr/bin/env bash
chmod -R u+x *