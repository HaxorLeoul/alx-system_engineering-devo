# System engineering DevOps

This project automate some commands from the linux terminal
