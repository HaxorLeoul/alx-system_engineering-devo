# 0x14-mysql

## Install mysql

`sudo apt-get install mysql-server mysql-client`

