# Shell, permissions

This project has the main details to know about permissions on a Unix system

