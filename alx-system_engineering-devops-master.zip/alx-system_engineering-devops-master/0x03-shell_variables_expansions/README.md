# This project is for learning:
- Shell initialization files
- Variables
- Expansions
- Shell Arithmetic
- Alias command

And a few other things on the way :)
